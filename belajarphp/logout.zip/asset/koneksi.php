<?php

$conn = mysqli_connect('localhost', 'root', '', 'pkl', '3307');

?>
